speech2text
===========

Provides a Matlab framework for recording speech samples, training a Hidden Markov Model, and converting speech to text. 